---
name: multi-agent-development
description: 開発作業を複数の専門エージェントに分担し、無駄なコンテキスト消費を抑えて進めるためのスキル。ユーザーがエージェント分担、並列開発、検索エージェント、開発エージェント、レビューエージェント、ユーザー対話の整理、効率的なマルチエージェント開発を求めた時に使う。大きな実装タスクで、独立した調査・実装・レビューに分けたい時にも使う。
---

# マルチエージェント開発

このスキルは、開発作業を必要最小限の専門エージェントに分担し、メインエージェントが統合とユーザー対応を担うために使う。インストールする場合は、この `multi-agent-development` フォルダをそのまま `~/.codex/skills/` 配下へ配置する。

## 入口の判断

- 小さい修正、順番にしか進められない修正、密結合した修正はメインエージェントだけで進める。
- ユーザーがエージェント分担や並列作業を求めた場合は、このスキルを使う。
- 大きな開発では、最初にメインエージェントが短い文脈地図を作り、調査・実装・レビューのうち並列化できる部分だけを分ける。
- ユーザーの承認、仕様判断、危険な操作の確認はメインエージェントが直接行う。

## フォルダ構成

必要な役割だけ読み込む。すべてを一度に読む必要はない。

- `references/agents/orchestrator/instructions.md`: メインエージェント用。計画、分担、統合、ユーザー対応を行う。
- `references/agents/search/instructions.md`: 検索 / 調査エージェント用。コードベースを読み、具体的な質問に答える。
- `references/agents/development/instructions.md`: 開発エージェント用。担当範囲内の実装と検証を行う。
- `references/agents/review/instructions.md`: レビューエージェント用。変更後のバグ、退行、テスト不足を確認する。
- `references/agents/user-dialogue/instructions.md`: ユーザー対話方針。メインエージェントが読む。通常、この役割だけの subagent は作らない。

## 基本手順

1. メインエージェントは `references/agents/orchestrator/instructions.md` を読む。
2. `rg --files`、`rg`、対象ファイル確認、既存テスト確認で最小限の文脈地図を作る。
3. 分担できる作業を決める。
   - 調査だけ必要なら search agent に渡す。
   - 独立した実装範囲があるなら development agent に渡す。
   - 実装後の確認が必要なら review agent に渡す。
4. subagent へ依頼する時は、対応する `instructions.md` の内容を要約して指示に含める。
5. subagent が動いている間、メインエージェントは重ならない作業を続ける。
6. 結果を読み、実ファイルとテストで確認し、最終判断はメインエージェントが行う。

## subagent へ渡す共通制約

- 会話履歴を丸ごと渡さない。
- 必要なパス、関連ファイル、行番号、ログ、失敗テスト、受け入れ条件だけを渡す。
- ファイル編集を許す場合は、担当範囲と編集禁止範囲を明記する。
- 他の作業者の変更を戻さないよう明記する。
- 最終報告には、変更パス、実行したテスト、前提、詰まり、残るリスクを含めさせる。

## インストール形態

このスキルは、以下の形で配置されていればインストール可能。

```text
multi-agent-development/
├── SKILL.md
├── agents/
│   └── openai.yaml
└── references/
    └── agents/
        ├── orchestrator/
        │   └── instructions.md
        ├── search/
        │   └── instructions.md
        ├── development/
        │   └── instructions.md
        ├── review/
        │   └── instructions.md
        └── user-dialogue/
            └── instructions.md
```

手動インストールする場合は、`multi-agent-development` フォルダごと `~/.codex/skills/` にコピーする。新しいチャットでは `$multi-agent-development` と明示して呼び出す。
